package com.emarket.emarket.controllers;

import lombok.Data;

@Data
public class RegistrationRequest {
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getMobile() {
        return mobile;
    }

    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String mobile;


    public CharSequence getPassword() {
        return password;
    }
}