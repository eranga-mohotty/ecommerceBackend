package com.emarket.emarket.controllers;

import com.emarket.emarket.user.User;
import com.emarket.emarket.user.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/register")
public class RegistrationController {

    private final UserRepository userRepository;

    public RegistrationController(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @PostMapping
    public ResponseEntity<String> register(@RequestBody RegistrationRequest registrationRequest) {
        // Check if the email is already registered
        if (userRepository.findByEmail(registrationRequest.getEmail()) != null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Email already registered");
        }

        // Create a new user and save it to the database
        User newUser = new User();
        newUser.setFirstName(registrationRequest.getFirstName());
        newUser.setLastName(registrationRequest.getLastName());
        newUser.setEmail(registrationRequest.getEmail());
        newUser.setMobile(registrationRequest.getMobile());


        // Hash the password before storing it in the database (as described in a previous response)
        String hashedPassword = new BCryptPasswordEncoder().encode(registrationRequest.getPassword());
        newUser.setPassword(hashedPassword);

        userRepository.save(newUser);

        return ResponseEntity.ok("Registration successful");
    }
}